package com.example.notebook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class delete extends AppCompatActivity {

    String nameDB="BookStore";
    String nameTable="notbook";
    int versionDB=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        Intent intent = getIntent();
        //获取传递的值
        String id= intent.getStringExtra("id");
        int position=Integer.parseInt(id);
        Button deleteButton = (Button) findViewById(R.id.button_delete);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                theNotebook note1=searchDB(position,nameDB,nameTable,versionDB);
                deleteDB(note1.id,nameDB,nameTable,versionDB);
                finish();
            }
        });
        Button returnButton = (Button) findViewById(R.id.button_return);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    void deleteDB(int id,String nameDB,String nameTable,int versionDB)
    {
        MyDatabaseHelper dbHelper ;dbHelper = new MyDatabaseHelper(this, nameDB+".db", null, versionDB);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String ID=Integer.toString(id);
        db.delete(nameTable, "id = ?", new String[]{ID});
    }
    theNotebook searchDB(int position,String nameDB,String nameTable,int versionDB)
    {
        theNotebook note1=new theNotebook();
        int po=0;
        MyDatabaseHelper dbHelper ;
        dbHelper = new MyDatabaseHelper(this, nameDB+".db", null, versionDB);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // 查询Book表中所有的数据
        Cursor cursor = db.query(nameTable, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                // 遍历Cursor对象，取出数据并打印
                int idint= cursor.getColumnIndex("id");
                int titleint=cursor.getColumnIndex("title");
                int nodeint=cursor.getColumnIndex("node");
                int authorint=cursor.getColumnIndex("author");
                int timeint=cursor.getColumnIndex("time");
                int id=cursor.getInt(idint);
                String title = cursor.getString(titleint);
                String note = cursor.getString(nodeint);
                String author = cursor.getString(authorint);
                String time = cursor.getString(timeint);
                System.out.print(id+note+author+time);
                if(po==position)
                {
                    note1.setId(id);
                    note1.setTitle(title);
                    note1.setAuthor(author);
                    note1.setTime(time);
                    note1.setNote(note);
                    po=po+1;
                }
                else
                {
                    po=po+1;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return note1;
    }
}