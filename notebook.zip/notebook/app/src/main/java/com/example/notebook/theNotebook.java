package com.example.notebook;

import java.util.ArrayList;
import java.util.List;

public class theNotebook {
    int id;
    String title;
    String note;
    String author;
    String time;

    theNotebook(){}
    theNotebook(int id,String title,String note,String author,String time)
    {
        this.id=id;
        this.title=title;
        this.note=note;
        this.author=author;
        this.time=time;
    }

    public void setId(int id) {
        this.id = id;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setNote(String note) {
        this.note = note;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public int getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }
    public String getNote() {
        return note;
    }
    public String getAuthor() {
        return author;
    }
    public String getTime() {
        return time;
    }
}
