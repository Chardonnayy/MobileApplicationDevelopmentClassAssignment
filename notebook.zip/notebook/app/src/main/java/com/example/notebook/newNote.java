package com.example.notebook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class newNote extends AppCompatActivity {

    String titleText="";
    String noteText="";
    String nameDB="BookStore";
    String nameTable="notbook";
    int versionDB=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sticky_notes);
        TextView title=(TextView)findViewById(R.id.title);
        TextView note=(TextView)findViewById(R.id.note);
        Intent intent = getIntent();

    }
    @Override
    protected void onPause() {
        super.onPause();
        EditText title=(EditText) findViewById(R.id.title);
        EditText node=(EditText) findViewById(R.id.note);
        String titleString=title.getText().toString();
        String nodeString=node.getText().toString();
        SimpleDateFormat SDF=new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        Date date=new Date(System.currentTimeMillis());
        String timeString=SDF.format(date);
        String authorString=getAuthorName();
        if(titleString.equals(titleText))
        {
            if(nodeString.equals(noteText))
            {
                Toast.makeText(this, "未输入，不保存", Toast.LENGTH_SHORT).show();
            }
            else
            {
                writeDB("未命名",nodeString,authorString,timeString,nameDB,nameTable,versionDB);
                Toast.makeText(this, "保存，未命名", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            if(nodeString.equals(noteText))
            {
                writeDB(titleString,"",authorString,timeString,nameDB,nameTable,versionDB);
                Toast.makeText(this, "保存，无内容", Toast.LENGTH_SHORT).show();
            }
            else
            {
                writeDB(titleString,nodeString,authorString,timeString,nameDB,nameTable,versionDB);
                Toast.makeText(this, "保存，写入数据库", Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void writeDB(String title,String node,String author,String time,String nameDB,String nameTable,int versionDB)
    {
        MyDatabaseHelper dbHelper ;dbHelper = new MyDatabaseHelper(this, nameDB+".db", null, versionDB);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();Intent intent = new Intent(this,stickyNotes.class);
        // 开始组装第一条数据
        values.put("title", title);
        values.put("node", node);
        values.put("author", author);
        values.put("time", time);
        db.insert(nameTable, null, values);// 插入第一条数据
        values.clear();
        db.close();
    }
    theNotebook searchDB(int position,String nameDB,String nameTable,int versionDB)
    {
        theNotebook note1=new theNotebook();
        int po=0;
        MyDatabaseHelper dbHelper ;
        dbHelper = new MyDatabaseHelper(this, nameDB+".db", null, versionDB);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // 查询Book表中所有的数据
        Cursor cursor = db.query(nameTable, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                // 遍历Cursor对象，取出数据并打印
                int idint= cursor.getColumnIndex("id");
                int titleint=cursor.getColumnIndex("title");
                int nodeint=cursor.getColumnIndex("node");
                int authorint=cursor.getColumnIndex("author");
                int timeint=cursor.getColumnIndex("time");
                int id=cursor.getInt(idint);
                String title = cursor.getString(titleint);
                String note = cursor.getString(nodeint);
                String author = cursor.getString(authorint);
                String time = cursor.getString(timeint);
                System.out.print(id+note+author+time);
                if(po==position)
                {
                    note1.setId(id);
                    note1.setTitle(title);
                    note1.setAuthor(author);
                    note1.setTime(time);
                    note1.setNote(note);
                }
                else
                {
                    po=po+1;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return note1;
    }
    public String getAuthorName(){
        SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
        //获取姓名
        String name = prefs.getString("name","");
        return name;
    }
}