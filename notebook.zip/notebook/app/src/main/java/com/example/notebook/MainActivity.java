package com.example.notebook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private MyDatabaseHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText authorName =(EditText)findViewById(R.id.author_name);
        restoreData();
        Button save_name = (Button) findViewById(R.id.save_name);
        save_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
            }
        });
        Button show_name = (Button) findViewById(R.id.show_name);
        show_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restoreData();
            }
        });
        dbHelper = new MyDatabaseHelper(this, "BookStore.db", null, 1);
        dbHelper.getWritableDatabase();
        Button addData = (Button) findViewById(R.id.add_data);
        addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues values = new ContentValues();
                Intent intent = new Intent(MainActivity.this, newNote.class);
                startActivity(intent);
            }
        });
        searchDB();
    }
    void searchDB()
    {
        ListView notebookList=(ListView)findViewById(R.id.notebookList);
        List<String> notebookListText = new ArrayList<String>();
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // 查询Book表中所有的数据
        Cursor cursor = db.query("notBook", null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                // 遍历Cursor对象，取出数据并打印
                int idint= cursor.getColumnIndex("id");
                int titleint=cursor.getColumnIndex("title");
                int nodeint=cursor.getColumnIndex("node");
                int authorint=cursor.getColumnIndex("author");
                int timeint=cursor.getColumnIndex("time");
                int id=cursor.getInt(idint);
                String title = cursor.getString(titleint);
                String node = cursor.getString(nodeint);
                String author = cursor.getString(authorint);
                String time = cursor.getString(timeint);
                System.out.print(id+node+author+time);
                notebookListText.add(title);
            } while (cursor.moveToNext());
        }
        cursor.close();
        Collections.reverse(notebookListText);
        ArrayAdapter<String> notbookText1 = new ArrayAdapter<String>(this,R.layout.list_item,notebookListText);//listdata和str均可
        notebookList.setAdapter(notbookText1);
        notebookList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, stickyNotes.class);
                String str =notebookListText.get(position);
                int i=notebookListText.size();
                int p=i-1-position;
                String k=Integer.toString(p);
                String idd=Integer.toString(position);
                intent.putExtra("data", k);
                intent.putExtra("id",k);
                startActivity(intent);
            }
        });
        notebookList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, delete.class);
                String str =notebookListText.get(position);
                int i=notebookListText.size();
                int p=i-1-position;
                String k=Integer.toString(p);
                intent.putExtra("id",k);
                startActivity(intent);
                return false;
            }
        });

    }
    @Override
    protected void onStart() {
        super.onStart();
        searchDB();
    }
    public void saveData(){
        SharedPreferences.Editor editor = getSharedPreferences("data", MODE_PRIVATE).edit();
        //获取姓名
        EditText name = (EditText) findViewById(R.id.author_name);
        editor.putString("name", name.getText().toString());
        editor.commit();
    }
    public void restoreData(){
        SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
        //获取姓名
        String name = prefs.getString("name","");
        EditText nameText = (EditText)findViewById(R.id.author_name);
        nameText.setText(name);
    }
    public String getAuthorName(){
        SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
        //获取姓名
        String name = prefs.getString("name","");
        return name;
    }
}
