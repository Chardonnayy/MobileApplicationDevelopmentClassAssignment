package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    String equation="";
    String equationText="";
    TextView text1;
    Button button_Negative;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1=(TextView) findViewById(R.id.text_1);
        button_Negative=(Button) findViewById(R.id.button_Negative);
        text1.setText(equation);
    }
    public void button_1_click(View view)
    {
        inputNumber("1");
    }
    public void button_2_click(View view)
    {
        inputNumber("2");
    }
    public void button_3_click(View view)
    {
        inputNumber("3");
    }
    public void button_4_click(View view)
    {
        inputNumber("4");
    }
    public void button_5_click(View view)
    {
        inputNumber("5");
    }
    public void button_6_click(View view)
    {
        inputNumber("6");
    }
    public void button_7_click(View view)
    {
        inputNumber("7");
    }
    public void button_8_click(View view)
    {
        inputNumber("8");
    }
    public void button_9_click(View view)
    {
        inputNumber("9");
    }
    public void button_0_click(View view)
    {
        inputNumber("0");
    }
    public void button_Addition_click(View view)
    {
        inputSymblo("+");
    }
    public void button_Subtraction_click(View view)
    {
        inputSymblo("-");
    }
    public void button_Multiplication_click(View view)
    {
        inputSymblo("×");
    }
    public void button_DivisionMethod_click(View view)
    {
        inputSymblo("÷");
    }
    public void button_Power_click(View view)
    {
        inputSymblo("^");
    }
    public void button_Point_click(View view)
    {
        inputSymblo(".");
    }
    public void button_Negative_click(View view)
    {
        addNegative();
    }
    public void button_X_click(View view)
    {
        back();
    }
    public void button_C_click(View view)
    {
        clear();
    }
    public void button_EqualTo_click(View view)
    {
        toCalculate();
    }
    public void toCalculate()
    {
        if(equation.equals(""))
        {}
        else
       {
            String result =calculate(equation);
            if(result.equals("mistake0"))
            {
                result="除数不能为0";
            }
            else if(result.equals("NaN"))
            {
                result="无解";
            }
            else
            {
                result = equationText + "=" + calculate(equation);
            }
            text1.setText(result);
            equation = "";
            equationText = "";
        }
    }
    public void addNegative()
    {
        String q;
        if(equation.equals(""))
        {
            q = "";
        }
        else
        {
            q=equation.substring(equation.length()-1);
        }
        if(q.equals("")||q.equals("+")||q.equals("-")||q.equals("×")||q.equals("÷")||q.equals("^"))
        {
            equation=equation+"f";
            equationText=equationText+"-";
        }
        text1.setText(equationText);
    }
    public void back()
    {
        int l=equation.length();
        if(l>0)
        {
            equation = equation.substring(0, l - 1);
            equationText = equationText.substring(0, l - 1);
        }
        text1.setText(equationText);
    }
    public void clear()
    {
        equation = "";
        equationText = "";
        text1.setText(equationText);
    }
    public void inputNumber(String number)
    {
        equation = equation + number;
        equationText=equationText+number;
        text1.setText(equationText);
    }
    public void inputSymblo(String symblo)
    {
        String q;
        if(equation.equals(""))
        {
            q = "";
        }
        else
        {
            q=equation.substring(equation.length()-1);
        }
        if(q.equals("1")||q.equals("2")||q.equals("3")||q.equals("4")||q.equals("5")||
                q.equals("6")||q.equals("7")||q.equals("8")||q.equals("9")||q.equals("0"))
        {
            equation=equation+symblo;
            equationText=equationText+symblo;
        }
        if(q.equals("+")||q.equals("-")||q.equals("×")||q.equals("÷")||q.equals("^")||q.equals("."))
        {
            back();
            equation=equation+symblo;
            equationText=equationText+symblo;
        }
        text1.setText(equationText);
    }

    public static String calculate(String equation)
    {
        double firstNumber=0;
        double secondNumber=0;
        String transformReturn="";
        double result=0;
        int l=equation.length();
        int symbloLocation=0;
        String q=equation.substring(equation.length()-1);
        if(q.equals("+")||q.equals("-")||q.equals("×")||q.equals("÷")||q.equals("^"))
        {
            equation=equation.substring(0,l-1);
            l=l-1;
        }
        else if(q.equals("f"))
        {
            equation=equation.substring(0,l-2);
            l=l-2;
        }
        symbloLocation=getLocation(equation);
        if(symbloLocation==-1)
        {
            String j=equation.substring(0,1);
            if(j.equals("f"))
            {
                equation="-"+equation.substring(1,l);
            }
            transformReturn=equation;
            return transformReturn;
        }
        else
        {
            String first="";
            String second="";
            String symblo="";
            first=equation.substring(0,symbloLocation);
            second=equation.substring(symbloLocation+1,l);
            symblo=equation.substring(symbloLocation,symbloLocation+1);
            String firstCalculate=calculate(first);
            String secondCalculate=calculate(second);
            if(firstCalculate.equals("mistake0")||secondCalculate.equals("mistake0"))
            {
                return "mistake0";
            }
            else
            {
                firstNumber=Double.valueOf(firstCalculate.toString());
                secondNumber=Double.valueOf(secondCalculate.toString());
            }
            if(symblo.equals("+"))
            {
                result=firstNumber+secondNumber;
                transformReturn=""+result;
                return transformReturn;
            }
            if(symblo.equals("-"))
            {
                result=firstNumber-secondNumber;
                transformReturn=""+result;
                return transformReturn;
            }
            if(symblo.equals("×"))
            {
                result=firstNumber*secondNumber;
                transformReturn=""+result;
                return transformReturn;
            }
            if(symblo.equals("÷"))
            {
                if(secondNumber==0)
                {
                    return "mistake0";
                }
                else
                {
                    result=firstNumber/secondNumber;
                    transformReturn=""+result;
                    return transformReturn;
                }
            }
            if(symblo.equals("^"))
            {
                result=Math.pow(firstNumber,secondNumber);
                transformReturn=""+result;
                return transformReturn;
            }
            return "-1";
        }

    }
    public static int getLocation(String equation)
    {
        int locationAddition=equation.lastIndexOf('+');
        int locationSubtraction=equation.lastIndexOf('-');
        int locationMultiplication=equation.lastIndexOf('×');
        int locationDivisionMethod=equation.lastIndexOf('÷');
        int locationPower=equation.lastIndexOf('^');
        if(locationAddition==-1)
        {
            locationAddition=-99999;
        }
        if(locationSubtraction==-1)
        {
            locationSubtraction=-99999;
        }
        if(locationMultiplication==-1)
        {
            locationMultiplication=-99999;
        }
        if(locationDivisionMethod==-1)
        {
            locationDivisionMethod=-99999;
        }
        if(locationPower==-1)
        {
            locationPower=-99999;
        }
        if(locationAddition>locationSubtraction)
        {
            return locationAddition;
        }
        else if(locationAddition<locationSubtraction)
        {
            return locationSubtraction;
        }
        else
        {
            if(locationMultiplication>locationDivisionMethod)
            {
                return locationMultiplication;
            }
            else if(locationMultiplication<locationDivisionMethod)
            {
                return locationDivisionMethod;
            }
            else
            {
                if(locationPower>0)
                {
                    return locationPower;
                }
                else
                {
                    return -1;
                }
            }
        }
    }
}