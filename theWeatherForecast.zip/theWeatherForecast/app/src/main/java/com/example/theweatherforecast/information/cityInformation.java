package com.example.theweatherforecast.information;
import com.google.gson.annotations.SerializedName;
public class cityInformation {
    @SerializedName("city")
    private String city;
    @SerializedName("citykey")
    private String citykey;
    @SerializedName("parent")
    private String parent;
    @SerializedName("updateTime")
    private String updateTime;
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getCitykey() {
        return citykey;
    }
    public void setCitykey(String citykey) {
        this.citykey = citykey;
    }
    public String getParent() {
        return parent;
    }
    public void setParent(String parent) {
        this.parent = parent;
    }
    public String getUpdateTime() {
        return updateTime;
    }
    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }
    @Override
    public String toString() {
        return "cityInformation{" +
                "city='" + city + '\'' +
                ", citykey='" + citykey + '\'' +
                ", parent='" + parent + '\'' +
                ", updateTime='" + updateTime + '\'' +
                '}';
    }
}
