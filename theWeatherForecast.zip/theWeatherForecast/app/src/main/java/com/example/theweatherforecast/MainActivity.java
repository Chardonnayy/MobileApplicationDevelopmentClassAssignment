package com.example.theweatherforecast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.theweatherforecast.information.weatherInformation;
import com.example.theweatherforecast.tool.*;
import com.google.gson.Gson;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    weatherInformation weatherInformation1;
    private Handler handler1=new Handler(Looper.myLooper())
    {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            if(msg.what==0)
            {
                TextView textout=(TextView) findViewById(R.id.textout);
                String weather=(String) msg.obj;
                Log.d("fan","主线程天气数据:"+weather);
                if(weather!="")
                {
                    //解析json
                    Gson gson =new Gson();
                    weatherInformation1=gson.fromJson(weather, weatherInformation.class);
                    Log.d("fan","解析程天气数据:"+weatherInformation1.toString());

                    if(weatherInformation1.toString().equals("weatherInformation{date='null', time='null', cityInfo=null, data=null}"))
                    {
                        textout.setText("输入编码不存在");
                    }
                    else
                    {
                        if (weatherInformation1 == null)
                        {
                            return;
                        }
                        //分类拿取天气信息
                        String city = weatherInformation1.getCityInfo().getCity();
                        String parent = weatherInformation1.getCityInfo().getParent();
                        String date = weatherInformation1.getDate();
                        String time = weatherInformation1.getTime();
                        String shidu = weatherInformation1.getData().getShidu();
                        String wendu = weatherInformation1.getData().getWendu();
                        String pm25 = weatherInformation1.getData().getPm25();
                        String cityID=weatherInformation1.getCityInfo().getCitykey();
                        SimpleDateFormat SDF = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
                        Date searchDate = new Date(System.currentTimeMillis());
                        String SearchDate = SDF.format(searchDate);
                        String output = "";//拼接输出内容
                        output = parent + "\n" +
                                city + "\n" +
                                "日期:" + date + "\n" +
                                "天气更新时间:" + time + "\n" +
                                "湿度:" + shidu + "\n" +
                                "温度:" + wendu + "\n" +
                                "pm2.5:" + pm25 + "\n" +
                                "查询时间:" + SearchDate + "\n";
                        outputProcessing(output);//输出处理
                        refreshclick();//刷新
                        searchclick();//搜索
                        focusclick();//关注
                    }
                }
                else
                {
                    textout.setText("输入错误");
                }
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();//自关注初始启动显示
        refreshclick();//刷新
        searchclick();//搜索
        setList();//关注
    }
    public void saveDatakey(String key,String value){
        SharedPreferences.Editor editor = getSharedPreferences("data", MODE_PRIVATE).edit();
        //存值
        editor.putString(key, value);
        editor.commit();
    }
    public String findData(String key){
        SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
        //取值
        String date = prefs.getString(key,"");
        return date;
    }
    private void setList()
    {
        //链表
        ListView focusList=(ListView)findViewById(R.id.focusList);
        List<String> focusListText = new ArrayList<String>();
        //填充数据
        for(int i=0;i<3;i++)
        {
            String j=Integer.toString(i);
            String title =findData(j);
            focusListText.add(title);
        }
        //显示链表
        ArrayAdapter<String> focusListText1 = new ArrayAdapter<String>(this,R.layout.list_item,focusListText);//listdata和str均可
        focusList.setAdapter(focusListText1);
        //单击快速查询
        focusList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String j=Integer.toString(position);
                String k=Integer.toString(position+3);
                String title=findData(j);
                String titleid=findData(k);
                if(title.equals(""))
                {}
                else
                {
                    saveDatakey("refresh","f");
                    getweather(titleid);
                }
            }
        });
        //长按删除
        focusList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String j=Integer.toString(position);
                String k=Integer.toString(position+3);
                String title=findData(j);
                if(title.equals(""))
                {}
                else
                {
                    saveDatakey(j,"");
                    saveDatakey(k,"");
                    Log.d("fan","长按");
                    setList();
                }
                return false;
            }
        });
    }
    private void getweather(String cityId)
    {
        TextView textout=(TextView) findViewById(R.id.textout);
        String r=findData("refresh");
        String iD1=findData("di1");
        String iD2=findData("di2");
        String iD3=findData("di3");
        Log.d("fan","@@@"+iD1+""+iD2+""+iD3);
        if(cityId.equals(iD1)&&r.equals("f"))
        {
                String output = findData("di11");
                textout.setText(output);
                Log.d("fan", "和1一样");
        }
        else if(cityId.equals(iD2)&&r.equals("f"))
        {
            String output=findData("di22");
            textout.setText(output);
            Log.d("fan","和2一样");
        }
        else if(cityId.equals(iD3)&&r.equals("f"))
        {
                String output = findData("di33");
                textout.setText(output);
                Log.d("fan", "和3一样");
        }
        else
        {
            if(r.equals("t")&&cityId.equals(iD1))
            {
                saveDatakey("refresh","1");
                Log.d("fan", "1刷新");
            }
            else if(r.equals("t")&&cityId.equals(iD2))
            {
                saveDatakey("refresh","2");
                Log.d("fan", "2刷新");
            }
            else if(r.equals("t")&&cityId.equals(iD3))
            {
                saveDatakey("refresh","3");
                Log.d("fan", "3刷新");
            }
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String weatherString = weatherTool.getWeatherResult(cityId);
                    //使用handler向主线程回传
                    Message message = Message.obtain();
                    message.what = 0;
                    message.obj = weatherString;
                    handler1.sendMessage(message);
                }
            }).start();
        }
    }
    private void searchclick()
    {
        EditText cityId=(EditText)findViewById(R.id.cityId);
        Button search=(Button) findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String CityId=cityId.getText().toString();
                saveDatakey("refresh","f");
                getweather(CityId);
            }
        });
    }
    private void refreshclick()
    {
        EditText cityId=(EditText)findViewById(R.id.cityId);
        Button refresh = (Button) findViewById(R.id.refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String CityId = cityId.getText().toString();
                saveDatakey("refresh","t");
                getweather(CityId);
            }
        });
    }
    private void focusclick()
    {
        //EditText cityId=(EditText)findViewById(R.id.cityId);
        Button focus = (Button) findViewById(R.id.focus);
        focus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("fan", "关注了。。。");
                String title1=findData("0");
                String title2=findData("1");
                String title3=findData("2");
                if(title1.equals(""))
                {
                    saveDatakey("0",weatherInformation1.getCityInfo().getCity().toString());
                    saveDatakey("3",weatherInformation1.getCityInfo().getCitykey().toString());
                }
                else if(title2.equals(""))
                {
                    saveDatakey("1",weatherInformation1.getCityInfo().getCity().toString());
                    saveDatakey("4",weatherInformation1.getCityInfo().getCitykey().toString());
                }
                else if(title3.equals(""))
                {
                    saveDatakey("2",weatherInformation1.getCityInfo().getCity().toString());
                    saveDatakey("5",weatherInformation1.getCityInfo().getCitykey().toString());
                }
                setList();
            }
        });
    }

    private void outputProcessing(String output)
    {
        //EditText cityId=(EditText)findViewById(R.id.cityId);
        TextView textout=(TextView) findViewById(R.id.textout);
        String r=findData("refresh");
        String iD1=findData("di1");
        String iD2=findData("di2");
        String iD3=findData("di3");
        String iD4=findData("di11");
        String iD5=findData("di22");
        String iD6=findData("di33");
        //saveData(cityID,iD1,iD2,output,iD4,iD5);
        if(r.equals("f"))
        {
            saveDatakey("di1",weatherInformation1.getCityInfo().getCitykey());
            saveDatakey("di2",iD1);
            saveDatakey("di3",iD2);
            saveDatakey("di11",output);
            saveDatakey("di22",iD4);
            saveDatakey("di33",iD5);
        }
        else if(r.equals("1"))
        {
            saveDatakey("di11",output);
        }
        else if(r.equals("2"))
        {
            saveDatakey("di22",output);
        }
        else if(r.equals("3"))
        {
            saveDatakey("di33",output);
        }
        textout.setText(output);
    }
    private void initialize()
    {
        String titleid1=findData("3");
        String titleid2=findData("4");
        String titleid3=findData("5");
        String CityId ="";
        if(titleid1.equals("")!=true)
        {
            CityId = titleid1;
        }
        else if(titleid2.equals("")!=true)
        {
            CityId = titleid2;
        }
        else if(titleid3.equals("")!=true)
        {
            CityId = titleid3;
        }
        saveDatakey("refresh","f");
        getweather(CityId);
    }

}