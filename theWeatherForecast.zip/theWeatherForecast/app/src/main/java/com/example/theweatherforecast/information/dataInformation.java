package com.example.theweatherforecast.information;

import com.google.gson.annotations.SerializedName;

public class dataInformation {

    @SerializedName("shidu")
    private String shidu;

    @SerializedName("pm25")
    private String pm25;

    @SerializedName("pm10")
    private String pm10;

    @SerializedName("quality")
    private String quality;

    @SerializedName("wendu")
    private String wendu;

    @SerializedName("ganmao")
    private String ganmao;


    public String getShidu() {
        return shidu;
    }

    public void setShidu(String shidu) {
        this.shidu = shidu;
    }

    public String getPm25() {
        return pm25;
    }

    public void setPm25(String pm25) {
        this.pm25 = pm25;
    }

    public String getPm10() {
        return pm10;
    }

    public void setPm10(String pm10) {
        this.pm10 = pm10;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getWendu() {
        return wendu;
    }

    public void setWendu(String wendu) {
        this.wendu = wendu;
    }

    public String getGanmao() {
        return ganmao;
    }

    public void setGanmao(String ganmao) {
        this.ganmao = ganmao;
    }


    @Override
    public String toString() {
        return "dataInformation{" +
                "shidu='" + shidu + '\'' +
                ", pm25='" + pm25 + '\'' +
                ", pm10='" + pm10 + '\'' +
                ", quality='" + quality + '\'' +
                ", wendu='" + wendu + '\'' +
                ", ganmao='" + ganmao + '\'' +
                '}';
    }
}
