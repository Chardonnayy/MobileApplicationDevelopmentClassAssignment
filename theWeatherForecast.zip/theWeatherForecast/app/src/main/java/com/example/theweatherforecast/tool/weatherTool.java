package com.example.theweatherforecast.tool;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class weatherTool {

    public static final String URLPREFIX="http://t.weather.itboy.net/api/weather/city/";

    public static String doGet(String urlInput)
    {
        String result ="";

        HttpURLConnection connection=null;

        InputStreamReader inputStreamReader = null;

        BufferedReader bufferedReader=null;
        try
        {
            URL url =new URL(urlInput);
            //连接网络
            try {
                connection=(HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(3000);

                //冲连接读取数据
                InputStream inputStream= connection.getInputStream();
                inputStreamReader=new InputStreamReader(inputStream);
                //二进制流送入缓冲区
                bufferedReader=new BufferedReader(inputStreamReader);
                StringBuilder stringBuilder=new StringBuilder();
                //逐行拼接字符串
                String line="";
                while ((line= bufferedReader.readLine())!=null)
                {
                    stringBuilder.append(line);
                }
                result= stringBuilder.toString();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            if(connection!=null)
            {
                connection.disconnect();
            }
            if(inputStreamReader!=null)
            {
                try {
                    inputStreamReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(bufferedReader!=null)
            {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }



    public static String getWeatherResult(String cityId)
    {
        String result ="";
        //URL拼接
        //“http://t.weather.itboy.net/api/weather/city/+city_code”
        String weatherURL=URLPREFIX+cityId;
        Log.d("fan","天气URL:"+weatherURL);

        result=doGet(weatherURL);
        Log.d("fan","天气结果:"+result);

        return result;
    }
}
