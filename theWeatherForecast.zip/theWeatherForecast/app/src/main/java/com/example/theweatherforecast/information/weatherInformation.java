package com.example.theweatherforecast.information;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class weatherInformation
{
    @SerializedName("date")
    private String date;
    @SerializedName("")
    private String time;//Gson
    @SerializedName("cityInfo")
    private cityInformation cityInfo;
    @SerializedName("data")
    private dataInformation data;
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public cityInformation getCityInfo() {
        return cityInfo;
    }
    public void setCityInfo(cityInformation cityInfo) {
        this.cityInfo = cityInfo;
    }
    public dataInformation getData() {
        return data;
    }
    public void setData(dataInformation data) {
        this.data = data;
    }
    @Override
    public String toString() {
        return "weatherInformation{" +
                "date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", cityInfo=" + cityInfo +
                ", data=" + data +
                '}';
    }
}
